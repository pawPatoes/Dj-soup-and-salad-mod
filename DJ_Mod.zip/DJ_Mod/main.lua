--- STEAMODDED HEADER
-- mod_id: DJ_Mod
-- mod_name: DJ Mod
-- mod_author: pawPatoes
-- prefix: DJ

SMODS.current_mod.mod_icon = "Keese.png"

local mod_config = {  
    spawn_keese = true,  
    spawn_sss = true,  
    spawn_seb = true  
}  
  
SMODS.current_mod.config_tab = function()  
    return {  
        n = G.UIT.ROOT,  
        config = { align = "cm", padding = 0.05, colour = G.C.BLACK },  
        nodes = {  
            { n = G.UIT.R, nodes = { { n = G.UIT.T, config = { text = "Toggle Start Items:", scale = 0.5, colour = G.C.WHITE } } } },  
            { n = G.UIT.R, nodes = {  
                { n = G.UIT.T, config = { text = "Spawn With Average Cryptid Joker", scale = 0.4, colour = G.C.PURPLE } },  
                create_toggle({  
                    label = '',  
                    ref_table = mod_config,  
                    ref_value = 'spawn_keese',  
                    col = true,  
                    hide_label = true  
                })  
            }},  
            { n = G.UIT.R, nodes = {  
                { n = G.UIT.T, config = { text = "Spawn With DJ Soup & Salad Joker", scale = 0.4, colour = G.C.GREEN } },  
                create_toggle({  
                    label = '',  
                    ref_table = mod_config,  
                    ref_value = 'spawn_sss',  
                    col = true,  
                    hide_label = true  
                })  
            }},  
            { n = G.UIT.R, nodes = {  
                { n = G.UIT.T, config = { text = "Spawn With Sebastion Pressure Joker", scale = 0.4, colour = G.C.RED } },  
                create_toggle({  
                    label = '',  
                    ref_table = mod_config,  
                    ref_value = 'spawn_seb',  
                    col = true,  
                    hide_label = true  
                })  
            }},  
        }  
    }  
end

SMODS.Atlas{ key = "dj_atlas", path = "stolethisfromcryptid.png", px = 71, py = 95 }
SMODS.Atlas{ key = "seb_atlas", path = "seb.png", px = 71, py = 95 }
SMODS.Atlas { key = "K_atlas", path = "stolethisfromcryptidsecond.png", px = 71, py = 95 }

SMODS.Joker {
    key = 'dj_sss',
    loc_txt = {
        name = 'DJ {C:red}soup {C:normal}& {C:green}salad',
        text = {
            "{C:red}D{C:attention}J{} gains {X:mult,C:white}X1{} Mult per {C:blue}hand played{},",
            "Loses {X:mult,C:white}X0.1{} Mult per {C:attention}card {C:red}discarded{}",
            "Currently {X:mult,C:white}X#1# {C:normal}Mult"
        }
    },
    config = { extra = { x_mult = 1 } },
    rarity = 4, cost = 20, blueprint_compat = true, atlas = 'dj_atlas', pos = { x = 0, y = 0 }, soul_pos = { x = 1, y = 0 }, discovered = true,
    loc_vars = function(self, info_queue, card) return { vars = { card.ability.extra.x_mult } } end,
    calculate = function(self, card, context)  
    if context.joker_main then  
        return { x_mult = card.ability.extra.x_mult }  
    end  
    if context.before and not context.blueprint then  
        card.ability.extra.x_mult = card.ability.extra.x_mult + 1  
        return { message = "Upgrade!", colour = G.C.MULT }  
    end  
    if context.discard and not context.blueprint and not card.ability.extra.downgraded_this_discard then  
        card.ability.extra.x_mult = math.max(1, card.ability.extra.x_mult - 0.1)  
        card.ability.extra.downgraded_this_discard = true -- Set flag to prevent repeated messages  
        return { message = "Downgraded!", colour = G.C.RED }  
    end  
    if context.end_of_round then  
        -- Reset the flag at the end of the round (or use another appropriate context)  
        card.ability.extra.downgraded_this_discard = false  
    end  
end
}

SMODS.Joker {  
    key = 'seb_pressure',  
    loc_txt = {  
        name = 'Sebastion Pressure',  
        text = { "{C:red}PLEASE GET OUT OF MY {C:attention}shop{}", "{C:red}IN LESS THAN {C:attention}3 SECONDS{}", "{C:green}and i'll give u mult :D{}", "{C:green}(Currently {X:mult,C:white}X#1# {C:green}Mult)" }  
    },  
    config = { extra = { x_mult = 1, timer = 0, in_shop = false } },  
    rarity = 2, atlas = 'seb_atlas', pos = { x = 0, y = 0 }, cost = 6, blueprint_compat = true, discovered = true,
    loc_vars = function(self, info_queue, card) return { vars = { card.ability.extra.x_mult } } end,  
    update = function(self, card, dt)  
        if G.STATE == G.STATES.SHOP then  
            if not card.ability.extra.in_shop then card.ability.extra.in_shop = true card.ability.extra.timer = love.timer.getTime() end  
        else  
            if card.ability.extra.in_shop then  
                local time_spent = love.timer.getTime() - card.ability.extra.timer
                if time_spent < 3 then card.ability.extra.x_mult = card.ability.extra.x_mult + 0.5 card_eval_status_text(card, 'extra', nil, nil, nil, {message = "GET OUT!", colour = G.C.RED})  
                else card.ability.extra.x_mult = 1 card_eval_status_text(card, 'extra', nil, nil, nil, {message = "WHAT IS THERE TO NOT UNDERSTAND?", colour = G.C.RED, scale = 0.4}) end  
                card.ability.extra.in_shop = false  
            end  
        end  
    end,  
    calculate = function(self, card, context) if context.joker_main then return { x_mult = card.ability.extra.x_mult } end end  
}

SMODS.Joker {
    key = 'average_cryptid',
    atlas = 'K_atlas', pos = { x = 0, y = 0 }, soul_pos = { x = 1, y = 0 }, rarity = 4, cost = 20, unlocked = true, discovered = true, blueprint_compat = true,
    loc_txt = { name = 'Average Cryptid Joker', text = { "{C:green}I LOVE {C:blue}JOLLY JOKERS{} I WILL GIVE U", "THE {X:purple,C:white}^999{} {C:red}MULT{} IF U HAVE ONE!" } },
    calculate = function(self, card, context)
        if context.joker_main then
            local has_jolly = false
            for _, v in ipairs(G.jokers.cards) do if v.config.center.key == 'j_jolly' then has_jolly = true break end end
            if has_jolly then return { message = '^999!', Emult_mod = 999, colour = G.C.PURPLE } end
        end
    end
}

local original_start_run = Game.start_run  
Game.start_run = function(self, args)  
    original_start_run(self, args)  
    if args and args.savetext then return end  
    G.E_MANAGER:add_event(Event({  
        trigger = "after", delay = 1,  
        func = function()  
            if mod_config.spawn_keese then SMODS.add_card({ set = "Joker", area = G.jokers, key = "j_DJ_average_cryptid", skip_materialize = true }) end
            if mod_config.spawn_sss then SMODS.add_card({ set = "Joker", area = G.jokers, key = "j_DJ_dj_sss", skip_materialize = true }) end
            if mod_config.spawn_seb then SMODS.add_card({ set = "Joker", area = G.jokers, key = "j_DJ_seb_pressure", skip_materialize = true }) end
            return true  
        end  
    }))  
end