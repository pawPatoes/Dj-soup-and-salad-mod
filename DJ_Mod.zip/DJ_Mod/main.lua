-- Thank you for reading this :3
SMODS.Sound { key = 'get_sound', path = 'get_sound.mp3' }    
SMODS.Sound { key = 'bruh_sound', path = 'bruh_sound.mp3' }

SMODS.current_mod.mod_icon = "Keese.png" -- idk why it wont work pls help

local mod_config = { 
    spawn_keese = true,  
    spawn_sss = true,  
    spawn_seb = true,
    spawn_balala = true,  
    spawn_first = true,
    spawn_walker = true
}

for k, v in pairs(SMODS.current_mod.config) do 
    mod_config[k] = v 
end
SMODS.current_mod.config = mod_config
  
SMODS.current_mod.config_tab = function() -- documentation my goat the second
    return {
        n = G.UIT.ROOT,
        config = { align = "cm", padding = 0.05, colour = G.C.BLACK },
        nodes = {
            { n = G.UIT.R, nodes = { { n = G.UIT.T, config = { text = "Toggle Start Items:", scale = 0.5, colour = G.C.WHITE } } } },
            
            { n = G.UIT.R, nodes = {
                { n = G.UIT.T, config = { text = "Spawn With Average Cryptid Joker", scale = 0.4, colour = G.C.PURPLE } },
                create_toggle({ label = '', ref_table = mod_config, ref_value = 'spawn_keese', col = true, hide_label = true })
            }},
            
            { n = G.UIT.R, nodes = {
                { n = G.UIT.T, config = { text = "Spawn With DJ Soup & Salad Joker", scale = 0.4, colour = G.C.GREEN } },
                create_toggle({ label = '', ref_table = mod_config, ref_value = 'spawn_sss', col = true, hide_label = true })
            }},
            
            { n = G.UIT.R, nodes = {
                { n = G.UIT.T, config = { text = "Spawn With Sebastion Pressure Joker", scale = 0.4, colour = G.C.RED } },
                create_toggle({ label = '', ref_table = mod_config, ref_value = 'spawn_seb', col = true, hide_label = true })
            }},
            
            { n = G.UIT.R, nodes = {
                { n = G.UIT.T, config = { text = "Spawn With Balala the Fairies", scale = 0.4, colour = G.C.GREEN } },
                create_toggle({ label = '', ref_table = mod_config, ref_value = 'spawn_balala', col = true, hide_label = true })
            }},

            { n = G.UIT.R, nodes = {
                { n = G.UIT.T, config = { text = "Spawn With My First Joker", scale = 0.4, colour = G.C.BLUE } },
                create_toggle({ label = '', ref_table = mod_config, ref_value = 'spawn_first', col = true, hide_label = true })
            }},

            { n = G.UIT.R, nodes = {
                { n = G.UIT.T, config = { text = "Spawn With New Sprite Joker", scale = 0.4, colour = G.C.PURPLE } },
                create_toggle({ label = '', ref_table = mod_config, ref_value = 'spawn_walker', col = true, hide_label = true })
            }},
        }
    }
end

SMODS.Atlas{ key = "dj_atlas", path = "stolethisfromcryptid.png", px = 71, py = 95 } -- i actually did
SMODS.Atlas{ key = "seb_atlas", path = "seb.png", px = 71, py = 95 }
SMODS.Atlas{ key = "K_atlas", path = "stolethisfromcryptidsecond.png", px = 71, py = 95 } -- i actually did the second feturing dante from the devil may cry series
SMODS.Atlas { key = "balala_atlas",path = "balala.png", px = 71, py = 95 }
SMODS.Atlas { key = "first_atlas",path = "first.png", px = 71, py = 95 }
SMODS.Atlas { key = "walker_atlas", path = "walker.png", px = 71, py = 95 }

SMODS.Joker { -- go my mult
    key = 'dj_sss',
    loc_txt = {
        name = 'DJ {C:red}soup {C:normal}& {C:green}salad', -- <-- the whole point of this mod
        text = {
            "{C:red}D{C:attention}J{} gains {X:mult,C:white}X1{} Mult per {C:blue}hand played{},",
            "Loses {X:mult,C:white}X0.1{} Mult per {C:attention}card {C:red}discarded{}",
            "Currently {X:mult,C:white}X#1# {C:normal} Mult"
        }
    },
    config = { extra = { x_mult = 1 } },
    rarity = 4, cost = 20, blueprint_compat = true, atlas = 'dj_atlas', pos = { x = 0, y = 0 }, soul_pos = { x = 1, y = 0 }, discovered = true,
    loc_vars = function(self, info_queue, card) return { vars = { card.ability.extra.x_mult } } end,
    calculate = function(self, card, context)  
    if context.joker_main then  
        return { x_mult = card.ability.extra.x_mult }  
    end  
    if context.before and not context.blueprint then  
        card.ability.extra.x_mult = card.ability.extra.x_mult + 1  
        return { message = "Upgrade!", colour = G.C.MULT }  
    end  
    if context.discard and not context.blueprint then  
        card.ability.extra.x_mult = math.max(1, card.ability.extra.x_mult - 0.1)  
        if context.other_card == G.hand.highlighted[1] then  
            return { message = "Downgraded!", colour = G.C.RED }  
        end  
    end
end
}

SMODS.Joker {    
    key = 'seb_pressure',  -- GET OUT!!!!!!!!!!  
    loc_txt = {    
        name = 'Sebastion Pressure',    
        text = { "{C:red}PLEASE GET OUT OF MY {C:attention}shop{}", "{C:red}IN LESS THAN {C:attention}3 SECONDS{}", "{C:green}and i'll give u mult :D{}", "{C:green}(Currently {X:mult,C:white}X#1# {C:green} Mult)" }    
    },    
    config = { extra = { x_mult = 1, timer = 0, in_shop = false } },    
    rarity = 2, atlas = 'seb_atlas', pos = { x = 0, y = 0 }, cost = 6, blueprint_compat = true, discovered = true,  
    loc_vars = function(self, info_queue, card) return { vars = { card.ability.extra.x_mult } } end,    
    update = function(self, card, dt)    
        if G.STATE == G.STATES.SHOP then   -- idk what this means documentation my goat     
            if not card.ability.extra.in_shop then card.ability.extra.in_shop = true card.ability.extra.timer = love.timer.getTime() end    
        else    
            if card.ability.extra.in_shop then   -- i want it to play a sound but idk how maybe tommorow   
                local time_spent = love.timer.getTime() - card.ability.extra.timer    
                if time_spent < 3 then    
                    card.ability.extra.x_mult = card.ability.extra.x_mult + 0.5    
                    card_eval_status_text(card, 'extra', nil, nil, nil, {message = "GET OUT!", colour = G.C.RED})    
                    play_sound('DJ_get_sound', 1, 0.5)  -- GET OUT    
                else    
                    card.ability.extra.x_mult = 1    
                    card_eval_status_text(card, 'extra', nil, nil, nil, {message = "KILL YOURSELF", colour = G.C.RED, scale = 0.4})    
                    play_sound('DJ_bruh_sound', 1, 0.5)  -- KILL YOURSELF    
                end      
                card.ability.extra.in_shop = false      
            end      
        end      
    end,  
    calculate = function(self, card, context) if context.joker_main then return { x_mult = card.ability.extra.x_mult } end end    
}

SMODS.Joker {
    key = 'average_cryptid', -- absolute peak
    atlas = 'K_atlas', pos = { x = 0, y = 0 }, soul_pos = { x = 1, y = 0 }, rarity = 4, cost = 20, unlocked = true, discovered = true, blueprint_compat = true, -- cryptid my goat
    loc_txt = { name = 'Average Cryptid Joker', text = { "{C:green}I LOVE {C:blue}JOLLY JOKERS{} I WILL GIVE U", "THE {X:purple,C:white}^999{} {C:red}MULT{} IF U HAVE ONE!" } },
    calculate = function(self, card, context)
        if context.joker_main then
            local has_jolly = false
            for _, v in ipairs(G.jokers.cards) do if v.config.center.key == 'j_jolly' then has_jolly = true break end end
            if has_jolly then return { message = '^999!', Emult_mod = 999, colour = G.C.PURPLE } end -- cryptid frfr
        end
    end
}

SMODS.Joker {
    key = 'balala_fairies',
    loc_txt = {
    name = 'BALALA the fairies',
    text = {
        "WE FIGHT THE {C:attention}BOSS BLINDS{}",
        "TO GIVE YOU {X:mult,C:white}X#1# {} MULT!"
    }
},
loc_vars = function(self, info_queue, card)
    return { vars = { card.ability.extra.x_mult } }
end,
    config = { extra = { x_mult = 4 } },
    rarity = 3, cost = 10, atlas = 'balala_atlas', pos = { x = 0, y = 0 }, 
    blueprint_compat = true, discovered = true,
    calculate = function(self, card, context)
        if context.joker_main and G.GAME.blind.boss then
            return {
                x_mult = card.ability.extra.x_mult,
            }
        end
    end
}

SMODS.Joker {
    key = 'my_first_joker',
    loc_txt = {
        name = 'My First Joker',
        text = {
            "MY FIRST {C:attention}JOKER{} DO U LIKE IT?",
            "{X:dark_edition,C:white}^#1#{} EVERYTHING!!!!!!!!!!"
        }
    },
    config = { extra = { exponent = 10 } },
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.exponent } }
    end,
    rarity = 3,
    atlas = 'first_atlas',
    pos = { x = 0, y = 0 },      
    soul_pos = { x = 1, y = 0 }, 
    cost = 10,
    blueprint_compat = true,

    calculate = function(self, card, context)
        if context.joker_main then
            return {
                Echips_mod = card.ability.extra.exponent,
                Emult_mod = card.ability.extra.exponent,
                message = "^10 EVERYTHING!!!!111!!",
                colour = G.C.PURPLE
            }
        end

        if context.after and not context.blueprint then
            local old_money = math.max(1, G.GAME.dollars)
            local new_money = math.floor(old_money ^ card.ability.extra.exponent)
            
            if new_money > G.GAME.dollars then
                ease_dollars(new_money - G.GAME.dollars)
                return {
                    message = "^10 Money!!11!!!!",
                    colour = G.C.MONEY
                }
            end
        end
    end
}

SMODS.Joker {
    key = 'new_sprite',
    loc_txt = {
        name = 'New sprite',
        text = {
            "Gives {X:purple,C:white}^#1#{} Mult for every",
            "\"atlas\" mention in {C:attention}main.lua{}",
            "{C:inactive}(You can add some yourself!)",
            "{C:red}PUT -- BEFORE SO IT DOESNT CRASH!{}",
            "{C:inactive}Total Bonus: {X:purple,C:white}^#2#{}",
            "{C:inactive}Current Count: {C:purple}#3#{}"
        }
    },
    config = { extra = { power_per_mention = 0.1 } },
    rarity = 4, 
    atlas = 'walker_atlas',
    pos = { x = 0, y = 0 },      
    soul_pos = { x = 1, y = 0 }, 
    cost = 20,
    blueprint_compat = true,
    discovered = true,
    unlocked = true,

    loc_vars = function(self, info_queue, card)
        local count = 0
        local mod_path = SMODS.Mods["DJ_Mod"].path
        local f = io.open(mod_path .. "main.lua", "r")
        if f then
            local content = f:read("*all")
            f:close()
            for _ in string.gmatch(content, "atlas") do
                count = count + 1
            end
        end
        return { vars = { card.ability.extra.power_per_mention, (count * card.ability.extra.power_per_mention), count } }
    end,

    calculate = function(self, card, context)
        if context.joker_main then
            local count = 0
            local mod_path = SMODS.Mods["DJ_Mod"].path
            local f = io.open(mod_path .. "main.lua", "r")
            if f then
                local content = f:read("*all")
                f:close()
                for _ in string.gmatch(content, "atlas") do
                    count = count + 1
                end
            end
            local total_pow = count * card.ability.extra.power_per_mention
            return {
                message = "^" .. total_pow .. "!",
                Emult_mod = total_pow,
                colour = G.C.PURPLE
            }
        end
    end
}

local original_start_run = Game.start_run
Game.start_run = function(self, args)  
    original_start_run(self, args)  
    if args and args.savetext then return end  
    G.E_MANAGER:add_event(Event({  
        trigger = "after", delay = 1,  
        func = function()  
            if mod_config.spawn_keese then SMODS.add_card({ set = "Joker", area = G.jokers, key = "j_DJ_average_cryptid", skip_materialize = true }) end
            if mod_config.spawn_sss then SMODS.add_card({ set = "Joker", area = G.jokers, key = "j_DJ_dj_sss", skip_materialize = true }) end
            if mod_config.spawn_seb then SMODS.add_card({ set = "Joker", area = G.jokers, key = "j_DJ_seb_pressure", skip_materialize = true }) end
            if mod_config.spawn_balala then SMODS.add_card({ set = "Joker", area = G.jokers, key = "j_DJ_balala_fairies", skip_materialize = true }) end
            if mod_config.spawn_first then SMODS.add_card({ set = "Joker", area = G.jokers, key = "j_DJ_my_first_joker", skip_materialize = true }) end
            if mod_config.spawn_walker then SMODS.add_card({ set = "Joker", area = G.jokers, key = "j_DJ_new_sprite", skip_materialize = true }) end
            return true  
        end  
    }))  
end
-- put ur atlases here!
--
--
--
-- add more -- if u need to!