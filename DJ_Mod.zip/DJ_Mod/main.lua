--- STEAMODDED DJ_MOD ---

SMODS.Atlas{ key = "seb_atlas", path = "seb.png", px = 71, py = 95 }  
SMODS.Atlas{ key = "GUY_atlas", path = "GUY.png", px = 71, py = 95 }  

-- ===============================  
-- Joker: Sebastion Pressure  
-- ===============================  
SMODS.Joker {  
    key = 'seb_pressure',  
    loc_txt = {  
        name = 'Sebastion Pressure',  
        text = {  
            "{C:red}PLEASE GET OUT OF MY {C:attention}shop{}",  
            "{C:red}IN LESS THAN {C:attention}3 SECONDS{}",  
            "{C:green}and i'll give u mult :D{}",  
            "{C:green}(Currently {X:mult,C:white}X#1# {C:green}Mult)"  
        }  
    },  
    config = { extra = { x_mult = 1, timer = 0, in_shop = false } },  
    rarity = 2, atlas = 'seb_atlas', pos = { x = 0, y = 0 }, cost = 6,  
    blueprint_compat = true,  
    loc_vars = function(self, info_queue, card)  
        return { vars = { card.ability.extra.x_mult } }  
    end,  
    update = function(self, card, dt)  
        if G.STATE == G.STATES.SHOP then  
            if not card.ability.extra.in_shop then  
                card.ability.extra.in_shop = true  
                card.ability.extra.timer = love.timer.getTime()  
            end  
        else  
            if card.ability.extra.in_shop then  
                local time_spent = love.timer.getTime() - card.ability.extra.timer
                if time_spent < 3 then  
                    card.ability.extra.x_mult = card.ability.extra.x_mult + 0.5  
                    card_eval_status_text(card, 'extra', nil, nil, nil, {message = "GET OUT!", colour = G.C.RED})  
                else  
                    card.ability.extra.x_mult = 1  
                    card_eval_status_text(card, 'extra', nil, nil, nil, {message = "WHAT IS THERE TO NOT UNDERSTAND?", colour = G.C.RED, scale = 0.4})  
                end  
                card.ability.extra.in_shop = false  
            end  
        end  
    end,  
    calculate = function(self, card, context)  
        if context.joker_main then return { x_mult = card.ability.extra.x_mult } end  
    end  
}  

-- ===============================  
-- Joker: DJ Soup And Salad (Fixed Scaling)
-- ===============================  
SMODS.Joker {  
    key = 'dj_sss',  
    loc_txt = {  
        name = 'DJ Soup And Salad',  
        text = {  
            "Gains {X:mult,C:white}X1{} Mult per {C:blue}hand played{},",  
            "Loses {X:mult,C:white}X0.1{} Mult per {C:attention}card {C:red}discarded{}",  
            "Currently {X:mult,C:white}X#1# {C:normal}Mult"  
        }  
    },  
    config = { extra = { x_mult = 1 } },  
    rarity = 4,
    atlas = 'GUY_atlas', pos = { x = 0, y = 0 }, cost = 20,  
    blueprint_compat = true,  
    loc_vars = function(self, info_queue, card)  
        return { vars = { card.ability.extra.x_mult } }  
    end,  
  
    calculate = function(self, card, context)  
        -- Scoring
        if context.joker_main then  
            return { x_mult = card.ability.extra.x_mult }  
        end  

        -- Gain Mult (Hand Played)
        -- We use 'joker_main' + 'before' to ensure it only happens ONCE per hand
        if context.before and not context.blueprint then
            card.ability.extra.x_mult = card.ability.extra.x_mult + 1
            return {
                message = "Upgrade!",
                colour = G.C.MULT
            }
        end

        -- Lose Mult (Discard)
        -- We check if 'other_card' is the FIRST card in the discard batch
        -- This stops the "Downgraded!" message from appearing 5 times at once
        if context.discard and not context.blueprint then
            card.ability.extra.x_mult = math.max(1, card.ability.extra.x_mult - 0.1)
            if context.other_card == context.full_hand[1] then
                return {
                    message = "Downgraded!",
                    colour = G.C.RED
                }
            end
        end
    end  
}

-- [Start Run code remains the same...]
-- ===============================  
-- Start Run Spawning  
-- ===============================  
local original_start_run = Game.start_run  
Game.start_run = function(self, args)  
    original_start_run(self, args)  
    if args and args.savetext then return end  
    G.E_MANAGER:add_event(Event({  
        trigger = "after", delay = 1,  
        func = function()  
            SMODS.add_card({ set = "Joker", area = G.jokers, key = "j_DJ_seb_pressure", skip_materialize = true })  
            SMODS.add_card({ set = "Joker", area = G.jokers, key = "j_DJ_dj_sss", skip_materialize = true })  
            return true  
        end  
    }))  
end